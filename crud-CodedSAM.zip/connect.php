<?php


$host='localhost';
$user='root';
$pass='';
$db = 'crud';

$con = mysqli_connect($host,$user,$pass,$db);
 


 
?>
